﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class AdminAddController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: AdminAdd
        public ActionResult addAdmin()
        {
            return View("addAdminUser");
        }
        
        [HttpPost]

        public ActionResult addAdmin(user u)
        {
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("adminUser", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("aName", u.userName.Trim());
                    sqlCmd.Parameters.AddWithValue("aEmail", u.userEmail.Trim());
                    sqlCmd.Parameters.AddWithValue("aContact", u.userContact);
                    string encryptedText = encryptString(u.userPassword.Trim());
                    sqlCmd.Parameters.AddWithValue("aPassword", encryptedText);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("adminHomePage", "Admin");
            }
            catch(Exception ex)
            {
                return RedirectToAction("addAdmin","AdminAdd");
            }
            
        }

        //function to encrypt password
        private string encryptString(string es)
        {
            string EncryptionKey = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            byte[] clearBytes = Encoding.Unicode.GetBytes(es);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    es = Convert.ToBase64String(ms.ToArray());
                }
            }
            return es;
        }
    }
}