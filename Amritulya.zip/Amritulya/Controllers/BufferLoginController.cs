﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class BufferLoginController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: BufferLogin
        [HttpPost]
        public ActionResult verifyUser(user u)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("verifyUser", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("uEmail", u.userEmail);
                string encryptedText = encryptString(u.userPassword.Trim());
                sqlDA.SelectCommand.Parameters.AddWithValue("uPassword", encryptedText);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                if (dtbl.Rows[0]["result"].ToString() == "Valid")
                {
                    FormsAuthenticationTicket FAT = new FormsAuthenticationTicket(1, u.userEmail.Trim(), DateTime.Now, DateTime.Now.AddMinutes(60), false, FormsAuthentication.FormsCookiePath);
                    string encFAT = FormsAuthentication.Encrypt(FAT);
                    Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookiePath, encFAT));
                    FormsAuthentication.RedirectFromLoginPage(u.userEmail.Trim(), true, FormsAuthentication.FormsCookiePath);
                    u.userMessage = "Success";
                    if (dtbl.Rows[0]["userType"].ToString() == "admin")
                        return RedirectToAction("adminHomePage", "Admin");
                    else
                        return RedirectToAction("placeOrder", "OrderPlace",new {pid=u.bufferString });
                }
                if (dtbl.Rows[0]["result"].ToString() == "Invalid")
                {
                    u.userMessage = "Invalid Credentials !";
                    //TempData["msg"] = "<script>alert('Invalid Credentials');</script>";
                }
                if (dtbl.Rows[0]["result"].ToString() == "Not Found")
                {
                    //no user found
                    u.userMessage = "User Not Found !";
                    //TempData["msg"] = "<script>alert('User Not Found');</script>";
                }

            }
            return RedirectToAction("placeOrderGuest", "OrderPlace", new {pid=u.bufferString,msg=u.userMessage });
            //return View("loginOptionGuest");
        }

        [HttpPost]
        public ActionResult register(user u)
        {
            try
            {
                bool flag = checkExisitingUser(u.userEmail); //check if a user is already registered
                if (flag == true)
                {
                    //check password
                    if (u.userPassword == u.userConfirmPassword)
                    {
                        //register.
                        using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                        {
                            sqlCon.Open();
                            MySqlCommand sqlCmd = new MySqlCommand("registerUser", sqlCon);
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("uName", u.userName.Trim());
                            sqlCmd.Parameters.AddWithValue("uEmail", u.userEmail.Trim());
                            sqlCmd.Parameters.AddWithValue("uContact", u.userContact);
                            string encryptedText = encryptString(u.userPassword.Trim());
                            sqlCmd.Parameters.AddWithValue("uPassword", encryptedText);
                            sqlCmd.ExecuteNonQuery();
                            sqlCon.Close();
                            u.userMessage = "";
                            //sendMail(u.userEmail, u.userName);
                            // TempData["msg"] = "<script>alert('Personal Details Added Successfully');</script>";
                        }
                        //return RedirectToAction("verifyUser", "BufferLogin",u);
                        verifyUser(u);                       
                        return RedirectToAction("placeOrder", "OrderPlace", new { pid = u.bufferString });
                        
                    }
                    else
                    {
                        //ask to check password
                        u.userRegMessage = "Password and Confirm Password Not Match";
                        //TempData["msg"] = "<script>alert('Password and Confirm Password Not Match');</script>";
                    }
                }
                else
                {
                    //throw message of existing user
                    u.userRegMessage = "User Already Exists";
                    //TempData["msg"] = "<script>alert('User Already Exists');</script>";
                }

                return RedirectToAction("placeOrderGuest", "OrderPlace", new {pid=u.bufferString,msg=u.userRegMessage });
            }
            catch (Exception ex)
            {
                return RedirectToAction("placeOrderGuest", "OrderPlace", new {pid=u.bufferString,msg="Some Error Occured,Please Retry !" });
            }
        }

        private string encryptString(string es)
        {
            string EncryptionKey = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            byte[] clearBytes = Encoding.Unicode.GetBytes(es);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    es = Convert.ToBase64String(ms.ToArray());
                }
            }
            return es;
        }

        private bool checkExisitingUser(string usEmail)
        {
            string res;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("checkExistingUser", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("uEmail", usEmail);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                res = dtbl.Rows[0]["result"].ToString();
                sqlCon.Close();
            }
            if (res == "True")
                return true;
            else
                return false;
        }
    }
}