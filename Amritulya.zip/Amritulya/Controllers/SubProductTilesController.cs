﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class SubProductTilesController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: SubProductTiles
        public ActionResult displaySubProductTiles(string pid)
        {
            string name = "";
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                name = ticket.Name;
            }

            var model = new List<SubProduct>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewSubProductTiles", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("cat", pid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var pr = new SubProduct();
                    pr.subproductNameLG = dtbl.Rows[i]["subproductNameLG"].ToString();
                    string img = dtbl.Rows[i]["subproductImgNameLG"].ToString();
                    pr.subproductImgNameLG = "/SubProdImgs/" + img;
                    pr.subproductDescriptionLG = dtbl.Rows[i]["subproductDescriptionLG"].ToString();
                    pr.subproductIdLG = Convert.ToInt32(dtbl.Rows[i]["subproductIdLG"].ToString());
                    pr.subproductPriceLG = dtbl.Rows[i]["subproductPriceLG"].ToString();
                    if (dtbl.Rows[i]["productNameLG"].ToString() != "")
                        pr.subproductCategory = dtbl.Rows[i]["productNameLG"].ToString();
                    else
                        pr.subproductCategory = "SubProduct";
                    model.Add(pr);
                }
                if (name != "")
                {
                    return View("viewSubProdTiles", model);

                }
                else
                {
                    return View("viewSubProdGuestTiles", model);
                }

            }
        }
    }
}