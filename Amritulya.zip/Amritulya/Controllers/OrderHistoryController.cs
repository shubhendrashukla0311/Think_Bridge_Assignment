﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;
namespace Amritulya.Controllers
{
    [Authorize]
    public class OrderHistoryController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: OrderHistory
        public ActionResult listOfOrders()
        {
            var model = new List<orders>();
            string name = "";
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            name = ticket.Name;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("showCustomerOrder", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("uEmail", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c != 0)
                {
                    for (int i = 0; i < c; i++)
                    {
                        var po = new orders();
                        po.orderID = Convert.ToInt32(dtbl.Rows[i]["orderID"].ToString());
                        po.orderQuantity = dtbl.Rows[i]["orderQuantity"].ToString();
                        po.orderProductName = dtbl.Rows[i]["orderProductName"].ToString();
                        DateTime dt = Convert.ToDateTime(dtbl.Rows[i]["orderDate"].ToString());
                        po.orderDate = dt.ToString("dddd, dd MMMM yyyy");
                        po.orderAmount = dtbl.Rows[i]["orderAmount"].ToString();
                        po.orderStatus = dtbl.Rows[i]["orderStatus"].ToString();
                        po.shipmentCompany = dtbl.Rows[i]["shipmentCompany"].ToString();
                        po.shipmentID = dtbl.Rows[i]["shipmentID"].ToString();
                        po.orderPhone = dtbl.Rows[0]["orderPhone"].ToString();
                        string img = dtbl.Rows[i]["subproductImgNameLG"].ToString();
                        po.orderImageName = "/SubProdImgs/" + img;
                        model.Add(po);
                    }
                    return View("showOrders", model);
                }
                else
                {
                    var po = new orders();
                    po.orderCountMessage = "0";
                    model.Add(po);
                    return View("showOrders", model);
                }
            }
            //return View("showOrders");
        }
    }
}