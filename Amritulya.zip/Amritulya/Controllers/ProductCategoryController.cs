﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class ProductCategoryController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ProductCategory
        public ActionResult viewCategories()
        {
            var model = new List<ProductCategory>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProductCategory", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c != 0)
                {
                    for (int i = 0; i < c; i++)
                    {
                        var pc = new ProductCategory();
                        pc.categoryName = dtbl.Rows[i]["prodCategoryLGName"].ToString();
                        pc.categoryID = Convert.ToInt32(dtbl.Rows[i]["prdCategoryLGID"].ToString());
                        pc.categoryAddedBy = dtbl.Rows[i]["prodAddedBy"].ToString();
                        DateTime ad = Convert.ToDateTime(dtbl.Rows[i]["prodAddedDate"].ToString());
                        pc.categoryAddDate = ad.ToString("dd/MM/yyyy");
                        model.Add(pc);
                    }
                }
                //else
                //{
                //    var us = new ProductCategory();
                //    //us.keyw = "History";
                //    model.Add(us);
                //}
                return View("viewProductCategories", model);
            }
            //return View("viewProductCategories");
        }

        [HttpPost]
        
        public ActionResult addCategory(ProductCategory ct)
        {
            try
            {
                HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
                FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                string name = ticket.Name;
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("addProdCategory", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("categoryName", ct.categoryName.Trim());
                    sqlCmd.Parameters.AddWithValue("prdAddBy", name);                  
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("viewCategories", "ProductCategory");
            }
            catch (Exception ex)
            {
                return RedirectToAction("viewCategories", "ProductCategory");
            }
            //return View();
        }

        public ActionResult removeCategory(string cID)
        {
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("deleteCategory", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("catID", cID.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
               
            }
            return RedirectToAction("viewCategories", "ProductCategory");
        }

        public ActionResult fetchCategoryDetails(string cID)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchCategoryDetails", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("catID", cID);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                var ct = new ProductCategory();
                ct.categoryID = Convert.ToInt32(dtbl.Rows[0]["prdCategoryLGID"].ToString());
                //string img = dtbl.Rows[0]["bookCoverName"].ToString();
                //bk.bookCoverName = "/bookCovers/" + img;
                ct.categoryName = dtbl.Rows[0]["prodCategoryLGName"].ToString();
                DateTime dt = Convert.ToDateTime(dtbl.Rows[0]["prodAddedDate"].ToString());
                ct.categoryAddDate = dt.ToString("dd-MM-yyyy");
                ct.categoryAddedBy = dtbl.Rows[0]["prodAddedBy"].ToString();                
                //cp.empId = dtbl.Rows[i]["empId"].ToString();                           
                return View("editCategoryDetails", ct);
            }
            //return View("editCategoryDetails");
        }

        
        public ActionResult editCategoryDetails(ProductCategory pc)
        {
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("editCategoryDetail", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("categoryName", pc.categoryName.Trim());
                    sqlCmd.Parameters.AddWithValue("prdAddBy", pc.categoryAddedBy);
                    sqlCmd.Parameters.AddWithValue("catID", pc.categoryID);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("viewCategories", "ProductCategory");
            }
            catch (Exception ex)
            {
                return RedirectToAction("viewCategories", "ProductCategory");
            }
        }
    }
}