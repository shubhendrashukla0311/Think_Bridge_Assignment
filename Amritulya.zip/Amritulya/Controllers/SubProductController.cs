﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class SubProductController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;

        private List<Product> loadCategory()
        {
            var l = new List<Product>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listProducts", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ct = new Product();
                    ct.productNameLG = (dtbl.Rows[k]["productNameLG"].ToString());
                    l.Add(ct);
                }
                return l;
            }
        }
        // GET: SubProduct
        
        public ActionResult addSubProduct()
        {
            var model = new List<SubProduct>();
            var list = new List<Product>();
            list = loadCategory();
            var p = new SubProduct();
            p.category = list;
            model.Add(p);
            return View("createSubProduct", model);
        }

        [HttpPost]
        
        public ActionResult addSubProduct(SubProduct spr, HttpPostedFileBase file)
        {
            //    
            //}
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            string imgName = "default.png";
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("addSubProduct", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("spName", spr.subproductNameLG.Trim());
                sqlCmd.Parameters.AddWithValue("spPrice", spr.subproductPriceLG.Trim());
                sqlCmd.Parameters.AddWithValue("spDesc", spr.subproductDescriptionLG);
                sqlCmd.Parameters.AddWithValue("spCat", spr.subproductCategory);
                sqlCmd.Parameters.AddWithValue("spWgt", spr.subproductWeight);
                sqlCmd.Parameters.AddWithValue("spColor", spr.subproductColors);
                sqlCmd.Parameters.AddWithValue("spAddBy", name);
                if (file != null)
                    imgName = uploadImage(file);
                sqlCmd.Parameters.AddWithValue("spImgName", imgName); //image name
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                //TempData["msg"] = "<script>alert('Book Added Successfully');</script>";
            }
            return RedirectToAction("listSubProducts", "ManageSubProduct");//redirect to 
        }
        
        private string uploadImage(HttpPostedFileBase file)
        {
            string uploadFolder = Request.PhysicalApplicationPath + "SubProdImgs\\"; //upload folder
            var myUniqueFileName = string.Format(@"{0}", Guid.NewGuid()); //GENERATE A UNIQUE FILE NAME
            string extension = System.IO.Path.GetExtension(file.FileName);
            if (file != null)
            {

                file.SaveAs(uploadFolder + myUniqueFileName + extension);

            }
            return myUniqueFileName + extension;

        }
    }
}