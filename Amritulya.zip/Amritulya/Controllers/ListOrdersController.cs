﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class ListOrdersController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ListOrders
        public ActionResult listAllOrders()
        {
            var model = new List<orders>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listAllOrders", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                //sqlDA.SelectCommand.Parameters.AddWithValue("bOwner", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var po = new orders();
                    po.orderID = Convert.ToInt32(dtbl.Rows[i]["orderID"].ToString());                    
                    po.userFirstName = dtbl.Rows[i]["orderFirstName"].ToString();
                    po.userLastName = dtbl.Rows[i]["orderLastName"].ToString();
                    po.orderProductName = dtbl.Rows[i]["orderProductName"].ToString();
                    po.orderDate = dtbl.Rows[i]["orderDate"].ToString();
                    po.orderAmount = dtbl.Rows[i]["orderAmount"].ToString();
                    po.orderStatus = dtbl.Rows[i]["orderStatus"].ToString();
                    if (dtbl.Rows[i]["orderType"].ToString() == "C")
                        po.orderType = "Customer";
                    else
                        po.orderType = "Guest";
                    model.Add(po);
                }
                return View("orderList", model);
            }
        }
        public ActionResult showFilteredOrders(string keyword)
        {
            var model = new List<orders>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listFilteredOrders", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("keyw", keyword);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c != 0)
                {
                    for (int i = 0; i < c; i++)
                    {
                        var po = new orders();
                        po.orderID = Convert.ToInt32(dtbl.Rows[i]["orderID"].ToString());
                        po.userFirstName = dtbl.Rows[i]["orderFirstName"].ToString();
                        po.userLastName = dtbl.Rows[i]["orderLastName"].ToString();
                        po.orderProductName = dtbl.Rows[i]["orderProductName"].ToString();
                        po.orderDate = dtbl.Rows[i]["orderDate"].ToString();
                        po.orderAmount = dtbl.Rows[i]["orderAmount"].ToString();
                        po.orderStatus = dtbl.Rows[i]["orderStatus"].ToString();
                        if (dtbl.Rows[i]["orderType"].ToString() == "C")
                            po.orderType = "Customer";
                        else
                            po.orderType = "Guest";
                        model.Add(po);
                    }
                }
                else
                {
                    var rq = new orders();
                    //rq.keyw = keyword;
                    model.Add(rq);
                }
                return View("orderList", model);
            }
        }
        public ActionResult editOrderDetails(string oid)
        {
            var po = new orders();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("orderDetail", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("ordID", oid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();                
                po.orderID = Convert.ToInt32(dtbl.Rows[0]["orderID"].ToString());
                po.userFirstName = dtbl.Rows[0]["orderFirstName"].ToString();
                po.userLastName = dtbl.Rows[0]["orderLastName"].ToString();
                po.orderProductName = dtbl.Rows[0]["orderProductName"].ToString();
                po.orderDate = dtbl.Rows[0]["orderDate"].ToString();
                po.orderAmount = dtbl.Rows[0]["orderAmount"].ToString();
                po.orderStatus = dtbl.Rows[0]["orderStatus"].ToString();
                po.shipmentCompany= dtbl.Rows[0]["shipmentCompany"].ToString();
                po.shipmentID = dtbl.Rows[0]["shipmentID"].ToString();
                po.orderAddress = dtbl.Rows[0]["orderAddress"].ToString();
                po.orderEmail= dtbl.Rows[0]["orderEmail"].ToString();
                po.orderPhone= dtbl.Rows[0]["orderPhone"].ToString();
                //cp.empId = dtbl.Rows[i]["empId"].ToString();                           
                return View("editOrder", po);
            }
        }

        public ActionResult updateOrder(orders or)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("updateOrders", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("ordID", or.orderID);
                sqlCmd.Parameters.AddWithValue("ordStatus", or.orderStatus.Trim());
                sqlCmd.Parameters.AddWithValue("shipComp", or.shipmentCompany.ToString().Trim());
                sqlCmd.Parameters.AddWithValue("shipID", or.shipmentID.ToString().Trim());
               
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                if (or.orderPriorStatus != or.orderStatus && or.orderStatus != "Confirmed")
                {
                    sendMail(or);
                }
                //TempData["msg"] = "<script>alert('Book Added Successfully');</script>"; shipID
            }
            return RedirectToAction("listAllOrders", "ListOrders");
        }
        public ActionResult printOrderReceipt(string oid)
        {
            var po = new orders();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("orderDetail", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("ordID", oid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                po.orderID = Convert.ToInt32(dtbl.Rows[0]["orderID"].ToString());
                po.userFirstName = dtbl.Rows[0]["orderFirstName"].ToString();
                po.userLastName = dtbl.Rows[0]["orderLastName"].ToString();
                po.orderProductName = dtbl.Rows[0]["orderProductName"].ToString();
                po.orderDate = dtbl.Rows[0]["orderDate"].ToString();
                po.orderAmount = dtbl.Rows[0]["orderAmount"].ToString();
                po.orderQuantity= dtbl.Rows[0]["orderQuantity"].ToString();
                po.orderUnitPrice = Convert.ToString(Convert.ToInt32(po.orderAmount) / Convert.ToInt32(po.orderQuantity));
                po.orderStatus = dtbl.Rows[0]["orderStatus"].ToString();
                po.shipmentCompany = dtbl.Rows[0]["shipmentCompany"].ToString();
                po.shipmentID = dtbl.Rows[0]["shipmentID"].ToString();
                po.orderAddress = dtbl.Rows[0]["orderAddress"].ToString();
                po.orderEmail= dtbl.Rows[0]["orderEmail"].ToString();
                po.orderPhone= dtbl.Rows[0]["orderPhone"].ToString();
                //cp.empId = dtbl.Rows[i]["empId"].ToString();                           
                return View("printReceipt", po);
            }
        }

        //private void sendMail(orders o)
        //{
        //    string mailBody = createBody(o);
        //    //send mail on successful registeration
        //    using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
        //    {
        //        sqlCon.Open();
        //        MySqlDataAdapter sqlDA = new MySqlDataAdapter("showEmail", sqlCon);
        //        sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        DataTable dtdbl = new DataTable();
        //        sqlDA.Fill(dtdbl);
        //        string em = dtdbl.Rows[0][0].ToString();
        //        string pass = dtdbl.Rows[0][1].ToString();
        //        sqlCon.Close();
        //        string fromaddr = em;
        //        string password = pass;
        //        MailMessage msg = new MailMessage();
        //        msg.Subject = "Your Order Has Been " + o.orderStatus;
        //        msg.From = new MailAddress(fromaddr);
        //        //msg.Body = "Hi" + " " + o.userFirstName + "," + "\r\n" + "\r\n" + "The status of your following order has changed:" + "\r\n" + "\r\n" + "Order ID : "+o.orderID + "\r\n" + "\r\n" + "Product Name : " + o.orderProductName + "\r\n" + "\r\n" + "Order Status :"+o.orderStatus + "\r\n" + "\r\n" +"Shipment Company :"+o.shipmentCompany+"\r\n"+"Shipment ID :"+o.shipmentID +"\r\n"+ "Please log in to your account for further Information on your order." + "\r\n" + "\r\n" + "Regards" + "\r\n" + "Team Little Garden";
        //        msg.Body = mailBody;
        //        msg.IsBodyHtml = true;

        //        msg.To.Add(new MailAddress(o.orderEmail));
        //        SmtpClient smtp = new SmtpClient();
        //        smtp.Host = "smtp.office365.com";
        //        //smtp.Port = 25;
        //        smtp.UseDefaultCredentials = false;
        //        smtp.EnableSsl = true;
        //        NetworkCredential nc = new NetworkCredential(fromaddr, password);
        //        smtp.Credentials = nc;
        //        smtp.Send(msg);
        //        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Order Confirmed')", true);
        //    }
        //}
        private string createBody(orders os)
        {
            string body = string.Empty;
            //using streamreader for reading my htmltemplate   

            using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/statusChange.html")))

            {

                body = reader.ReadToEnd();

            }

            body = body.Replace("{user}", os.userFirstName+" "+os.userLastName); //replacing the required things         
            body = body.Replace("{orderID}", Convert.ToString(os.orderID));
            body = body.Replace("{pName}", os.orderProductName);
            body = body.Replace("{currentStatus}", os.orderStatus);
            body = body.Replace("{shipComp}", os.shipmentCompany);
            body = body.Replace("{shipID}", os.shipmentID);
            return body;
        }

        private void sendMail(orders o)
        {
            string mailBody = createBody(o);
            //send mail on successful registeration
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlDataAdapter sqlDA = new MySqlDataAdapter("showEmail", sqlCon);
                    sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable dtdbl = new DataTable();
                    sqlDA.Fill(dtdbl);
                    string em = dtdbl.Rows[0][0].ToString();
                    string pass = dtdbl.Rows[0][1].ToString();
                    sqlCon.Close();
                    string fromaddr = em;
                    string password = pass;                  
                    MailMessage msg = new MailMessage();
                    SmtpClient client = new SmtpClient();
                    msg.From = new MailAddress(fromaddr);
                    msg.Subject = "Your Order Has Been " + o.orderStatus;
                    msg.Body = mailBody;
                    msg.To.Add(new MailAddress(o.orderEmail));
                    msg.IsBodyHtml = true;
                    client.EnableSsl = false;
                    //client.UseDefaultCredentials = false;
                    //client.Port = 465;
                    client.Port = 25;
                    //client.Host = "smtpout.secureserver.net";
                    client.Host = "relay-hosting.secureserver.net";
                    NetworkCredential nc = new NetworkCredential(fromaddr, password);
                    client.Credentials = nc;
                    client.Send(msg);
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}