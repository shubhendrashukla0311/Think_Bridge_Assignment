﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class EditDeleteAdminController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: EditDeleteAdmin
        public ActionResult adminEditor()
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var model = new List<user>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listAdmins", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("uEmail", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c != 0)
                {
                    for (int i = 0; i < c; i++)
                    {
                        var us = new user();
                        us.userId = dtbl.Rows[i]["userId"].ToString();                     
                        us.userName = dtbl.Rows[i]["userName"].ToString();
                        us.userEmail = dtbl.Rows[i]["userEmail"].ToString();
                        us.userContact = dtbl.Rows[i]["userContact"].ToString();                        
                        model.Add(us);
                    }
                }
                else
                {
                    var us = new user();
                    //us.keyw = "History";
                    model.Add(us);
                }
                return View("listAdmin", model);
            }
            //return View();
        }

        public ActionResult removeAdmin(string uID)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("deleteAdmin", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("aID", uID.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("adminEditor", "EditDeleteAdmin");
            //return View("adminEditor");
        }
    }
}