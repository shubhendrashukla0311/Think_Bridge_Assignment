﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class OrderPlaceController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: OrderPlace
        public ActionResult placeOrder(string pid)
        {
            string name = "";
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                name = ticket.Name;
            }

            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("loadSubProduct", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("sprID", pid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int count = dtbl.Rows.Count;
                var or = new orders();
                if (count != 0)
                {
                    or.orderProductName = dtbl.Rows[0]["subproductNameLG"].ToString();
                    or.orderProductID = Convert.ToInt32(dtbl.Rows[0]["subproductIdLG"].ToString());
                    or.orderUnitPrice = dtbl.Rows[0]["subproductPriceLG"].ToString();
                    if (name != "")
                        or.orderEmail = name;
                    else
                        or.orderEmail = "";
                }
                if (name != "")
                {
                    return View("placeOrderForm", or); //show with logged in user
                }
                else
                {

                    return View("placeOrderFormGuestView", or); //show with guest user
                    
                }
            }

            
            //return View("placeOrderForm");
        }

        [HttpPost]
        public ActionResult placeOrder(orders os)
        {
            string name = "";
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                name = ticket.Name;
            }
            
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("placeOrder", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("uEmail", os.orderEmail);
                sqlCmd.Parameters.AddWithValue("productID", os.orderProductID);
                sqlCmd.Parameters.AddWithValue("orderAddr", os.orderAddress);
                sqlCmd.Parameters.AddWithValue("ordQuant", os.orderQuantity);
                sqlCmd.Parameters.AddWithValue("ordAmt", Convert.ToInt32(os.orderQuantity)*Convert.ToInt32(os.orderUnitPrice));
                sqlCmd.Parameters.AddWithValue("ordFN", os.userFirstName);
                sqlCmd.Parameters.AddWithValue("ordLstName", os.userLastName);
                sqlCmd.Parameters.AddWithValue("prdName", os.orderProductName);
                sqlCmd.Parameters.AddWithValue("ordPhn", os.orderPhone);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                sendMail(os);
            }
            if (name != "")
            {
                return RedirectToAction("listOfOrders", "OrderHistory"); //show with logged in user
            }
            else
            {

                return RedirectToAction("viewHome", "WebHome"); //show with guest user

            }
            

        }

        public ActionResult placeOrderGuest(string pid,string msg)
        {
            user u = new user();
            if(msg == "None")
            {
                u.userMessage = "";
                u.userRegMessage = "";
            }
            if(msg== "Invalid Credentials !" || msg== "User Not Found !")
            {
                u.userMessage = msg;
                u.userRegMessage = "";
            }
            if(msg== "Password and Confirm Password Not Match" || msg=="User Already Exists" || msg== "Some Error Occured,Please Retry !")
            {
                u.userRegMessage = msg;
                u.userMessage = msg;
            }
            u.bufferString = pid;
            u.termsString = readTandC();
            return View("loginOptionGuest",u);
        }

        //private void sendMail(orders os)
        //{
        //    string mailBody = createBody(os);
        //    //send mail on successful registeration
        //    using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
        //    {
        //        sqlCon.Open();
        //        MySqlDataAdapter sqlDA = new MySqlDataAdapter("showEmail", sqlCon);
        //        sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        DataTable dtdbl = new DataTable();
        //        sqlDA.Fill(dtdbl);
        //        string em = dtdbl.Rows[0][0].ToString();
        //        string pass = dtdbl.Rows[0][1].ToString();
        //        sqlCon.Close();
        //        string fromaddr = em;
        //        string password = pass;
        //        MailMessage msg = new MailMessage();
        //        msg.Subject = "Order Placed Successfuly!";
        //        msg.From = new MailAddress(fromaddr);
        //        //msg.Body = "Hi" + " " + uName + "," + "\r\n" + "\r\n" + "Greetings From Team Little Garden !" + "\r\n" + "\r\n" + "Your Registration Is Completed Successfuly.Please login to the website by your registered email and browse through great products offered by us." + "\r\n" + "\r\n" + "Enjoy your gardening experience with our great products and technologies." + "\r\n" + "\r\n" + "For more information contact : +91-7337007444" + "\r\n" + "\r\n" + "Regards" + "\r\n" + "Team Little Garden";
        //        msg.Body = mailBody;
        //        msg.IsBodyHtml = true;
        //        msg.To.Add(new MailAddress(os.orderEmail));
        //        SmtpClient smtp = new SmtpClient();
        //        smtp.Host = "smtp.office365.com";
        //        //smtp.Port = 587;
        //        smtp.UseDefaultCredentials = false;
        //        smtp.EnableSsl = true;
        //        NetworkCredential nc = new NetworkCredential(fromaddr, password);
        //        smtp.Credentials = nc;
        //        smtp.Send(msg);
        //        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Order Confirmed')", true);
        //    }

        //}

            //new method
        private void sendMail(orders o)
        {
            string mailBody = createBody(o);
            //send mail on successful registeration
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlDataAdapter sqlDA = new MySqlDataAdapter("showEmail", sqlCon);
                    sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable dtdbl = new DataTable();
                    sqlDA.Fill(dtdbl);
                    string em = dtdbl.Rows[0][0].ToString();
                    string pass = dtdbl.Rows[0][1].ToString();
                    sqlCon.Close();
                    string fromaddr = em;
                    string password = pass;
                    MailMessage msg = new MailMessage();
                    SmtpClient client = new SmtpClient();
                    msg.From = new MailAddress(fromaddr);
                    msg.Subject = "Order Placed Successfuly!";
                    msg.Body = mailBody;
                    msg.To.Add(new MailAddress(o.orderEmail));
                    msg.IsBodyHtml = true;
                    client.EnableSsl = false;
                    //client.UseDefaultCredentials = false;
                    //client.Port = 465;
                    client.Port = 25;
                    //client.Host = "smtpout.secureserver.net";
                    client.Host = "relay-hosting.secureserver.net";
                    NetworkCredential nc = new NetworkCredential(fromaddr, password);
                    client.Credentials = nc;
                    client.Send(msg);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private string createBody(orders os)
        {
            string body = string.Empty;
            //using streamreader for reading my htmltemplate   

            using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/orderSuccess.html")))

            {

                body = reader.ReadToEnd();

            }
            DateTime today = DateTime.Today;
            body = body.Replace("{user}", os.userFirstName + " " + os.userLastName); //replacing the required things         
            body = body.Replace("{orderDate}", today.ToString("dd/MM/yyyy"));
            body = body.Replace("{pName}", os.orderProductName);
            body = body.Replace("{quant}", os.orderQuantity);
            body = body.Replace("{amount}", "₹ " + Convert.ToString(Convert.ToInt32(os.orderQuantity) * Convert.ToInt32(os.orderUnitPrice)));
            body = body.Replace("{contact}", os.orderPhone);
            body = body.Replace("{email}", os.orderEmail);
            body = body.Replace("{addr}", os.orderAddress);
            return body;
        }

        private string readTandC()
        {
            string body = string.Empty;
            //using streamreader for reading my htmltemplate   

            using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/termscondition.html")))

            {

                body = reader.ReadToEnd();

            }
            return body;
        }
    }
}