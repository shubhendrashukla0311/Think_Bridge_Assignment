﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class SubProduct
    {
        public int subproductIdLG { get; set; }
        public string subproductNameLG { get; set; }
        public string subproductPriceLG { get; set; }
        public string subproductDescriptionLG { get; set; }
        public string subproductImgNameLG { get; set; }
        public string subproductCategory { get; set; }
        public string subproductAvailability { get; set; }
        public int subproductRank { get; set; }
        public List<Product> category { get; set; }
        public string subproductAddedBy { get; set; }
        public string subproductAddDate { get; set; }
        public string subproductWeight { get; set; }
        public string subproductColors { get; set; }     
    }
}