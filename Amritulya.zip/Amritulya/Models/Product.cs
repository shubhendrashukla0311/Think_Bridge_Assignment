﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class Product
    {
        public int productIdLG { get; set; }
        public string productNameLG {get;set;}
        public string productDescriptionLG {get;set;}
        public string productImgNameLG {get;set;}
        public string productCategory {get;set;}
        public string productAvailability {get;set;}
        public int productRank {get;set;}
        public List<ProductCategory> category { get; set; }
        public string productAddedBy { get; set; }
        public string productAddDate { get; set; }
    }
}